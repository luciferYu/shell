INCLUDE_REGULAR_EXPRESSION
--------------------------

Include file scanning regular expression.

This read-only property specifies the regular expression used during
dependency scanning to match include files that should be followed.
See the include_regular_expression command.
