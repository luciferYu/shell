.. cmake-module:: ../../Modules/GetPrerequisites.cmake
