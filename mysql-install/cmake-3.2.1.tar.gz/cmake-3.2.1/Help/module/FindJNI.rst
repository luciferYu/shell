.. cmake-module:: ../../Modules/FindJNI.cmake
